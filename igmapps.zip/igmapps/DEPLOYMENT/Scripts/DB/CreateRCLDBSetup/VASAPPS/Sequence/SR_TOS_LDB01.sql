-- Create sequence 
create sequence SR_TOS_LDB01
minvalue 0
maxvalue 9999999999999999999999999
start with 1
increment by 1
cache 20
order;
