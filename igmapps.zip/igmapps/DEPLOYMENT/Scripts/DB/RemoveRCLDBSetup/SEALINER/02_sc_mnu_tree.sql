delete from sc_mnu_tree where program_id='TOS_OPR' and menu_id='ELL001';
delete from sc_mnu_tree where program_id='TOS_OPR' and menu_id='EDL001';
delete from sc_mnu_tree where program_id='CA' and menu_id='SECM';
delete from sc_mnu_tree where program_id='SECM' and menu_id='SECM005';
delete from sc_mnu_tree where program_id='SECM' and menu_id='SECM007';
delete from sc_mnu_tree where program_id='SECM' and menu_id='SECM010';
delete from sc_mnu_tree where program_id='DIM_MNT' and menu_id='SEDL004';
commit;