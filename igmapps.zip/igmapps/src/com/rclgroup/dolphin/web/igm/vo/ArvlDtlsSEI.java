package com.rclgroup.dolphin.web.igm.vo;

public class  ArvlDtlsSEI{
	public String nmbrOfPsngrs;
	//public String nmbrOfCrew;
	public String lightHouseDues;
	public String totalNoOfCntrsLanded;
	public String totalNoOfCntrsLoaded;
	public String totalNmbrOfPrsnsOnBoard;
	public String totalNoOfTrnsprtEqmtRprtdOnArvlDptr;
	public String totalNmbrOfTrnsprtContractsRprtdOnArvlDptr;
	public String getNmbrOfPsngrs() {
		return nmbrOfPsngrs;
	}
	public void setNmbrOfPsngrs(String nmbrOfPsngrs) {
		this.nmbrOfPsngrs = nmbrOfPsngrs;
	}

	/*
	 * public String getNmbrOfCrew() { return nmbrOfCrew; } public void
	 * setNmbrOfCrew(String nmbrOfCrew) { this.nmbrOfCrew = nmbrOfCrew; }
	 */
	public String getLightHouseDues() {
		return lightHouseDues;
	}
	public void setLightHouseDues(String lightHouseDues) {
		this.lightHouseDues = lightHouseDues;
	}
	public String getTotalNoOfCntrsLanded() {
		return totalNoOfCntrsLanded;
	}
	public void setTotalNoOfCntrsLanded(String totalNoOfCntrsLanded) {
		this.totalNoOfCntrsLanded = totalNoOfCntrsLanded;
	}
	public String getTotalNoOfCntrsLoaded() {
		return totalNoOfCntrsLoaded;
	}
	public void setTotalNoOfCntrsLoaded(String totalNoOfCntrsLoaded) {
		this.totalNoOfCntrsLoaded = totalNoOfCntrsLoaded;
	}
	public String getTotalNmbrOfPrsnsOnBoard() {
		return totalNmbrOfPrsnsOnBoard;
	}
	public void setTotalNmbrOfPrsnsOnBoard(String totalNmbrOfPrsnsOnBoard) {
		this.totalNmbrOfPrsnsOnBoard = totalNmbrOfPrsnsOnBoard;
	}
	public String getTotalNoOfTrnsprtEqmtRprtdOnArvlDptr() {
		return totalNoOfTrnsprtEqmtRprtdOnArvlDptr;
	}
	public void setTotalNoOfTrnsprtEqmtRprtdOnArvlDptr(String totalNoOfTrnsprtEqmtRprtdOnArvlDptr) {
		this.totalNoOfTrnsprtEqmtRprtdOnArvlDptr = totalNoOfTrnsprtEqmtRprtdOnArvlDptr;
	}
	public String getTotalNmbrOfTrnsprtContractsRprtdOnArvlDptr() {
		return totalNmbrOfTrnsprtContractsRprtdOnArvlDptr;
	}
	public void setTotalNmbrOfTrnsprtContractsRprtdOnArvlDptr(String totalNmbrOfTrnsprtContractsRprtdOnArvlDptr) {
		this.totalNmbrOfTrnsprtContractsRprtdOnArvlDptr = totalNmbrOfTrnsprtContractsRprtdOnArvlDptr;
	}
	
}