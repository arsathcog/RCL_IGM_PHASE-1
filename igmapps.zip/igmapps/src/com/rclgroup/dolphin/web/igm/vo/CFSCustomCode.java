package com.rclgroup.dolphin.web.igm.vo;

public class CFSCustomCode {

	private String cfsCustomCode;
	private String PodTerminal;

	public String getCfsCustomCode() {
		return cfsCustomCode;
	}

	public void setCfsCustomCode(String cfsCustomCode) {
		this.cfsCustomCode = cfsCustomCode;
	}

	public String getPodTerminal() {
		return PodTerminal;
	}

	public void setPodTerminal(String podTerminal) {
		PodTerminal = podTerminal;
	}
	
}
