package com.rclgroup.dolphin.web.igm.vo;

public class CrewEfctSEI{

	public String crewEfctsSeqNmbr;
	public String crewEfctDescCdd;
	public String crewEfctsDesc;
	public String crewEfctQntyOnbrd;
	public String crewEfctQntyCdOnbrd;

	public String getCrewEfctsSeqNmbr() {
		return crewEfctsSeqNmbr;
	}

	public void setCrewEfctsSeqNmbr(String crewEfctsSeqNmbr) {
		this.crewEfctsSeqNmbr = crewEfctsSeqNmbr;
	}

	public String getCrewEfctDescCdd() {
		return crewEfctDescCdd;
	}

	public void setCrewEfctDescCdd(String crewEfctDescCdd) {
		this.crewEfctDescCdd = crewEfctDescCdd;
	}

	public String getCrewEfctsDesc() {
		return crewEfctsDesc;
	}

	public void setCrewEfctsDesc(String crewEfctsDesc) {
		this.crewEfctsDesc = crewEfctsDesc;
	}

	public String getCrewEfctQntyOnbrd() {
		return crewEfctQntyOnbrd;
	}

	public void setCrewEfctQntyOnbrd(String crewEfctQntyOnbrd) {
		this.crewEfctQntyOnbrd = crewEfctQntyOnbrd;
	}

	public String getCrewEfctQntyCdOnbrd() {
		return crewEfctQntyCdOnbrd;
	}

	public void setCrewEfctQntyCdOnbrd(String crewEfctQntyCdOnbrd) {
		this.crewEfctQntyCdOnbrd = crewEfctQntyCdOnbrd;
	}
}