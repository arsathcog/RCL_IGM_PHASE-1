package com.rclgroup.dolphin.web.igm.vo;

public class ImportGenralManifestExcel {
	private String blNo;
	private String customCode;
	private String dpdMovement;
	private String dpdCode;
public ImportGenralManifestExcel() {
	
}

	public String getBlNo() {
		return blNo;
	}
	public void setBlNo(String blNo) {
		this.blNo = blNo;
	}
	public String getCustomCode() {
		return customCode;
	}
	public void setCustomCode(String customCode) {
		this.customCode = customCode;
	}
	public String getDpdMovement() {
		return dpdMovement;
	}
	public void setDpdMovement(String dpdMovement) {
		this.dpdMovement = dpdMovement;
	}
	public String getDpdCode() {
		return dpdCode;
	}
	public void setDpdCode(String dpdCode) {
		this.dpdCode = dpdCode;
	}




}
