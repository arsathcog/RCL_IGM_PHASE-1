package com.rclgroup.dolphin.web.igm.vo;

public class MarksNumber {
	
	private String blNO;
	
	private String MarksNumbers;
	
	private String Description;
	
	
	
	public String getBlNO() {
		return blNO;
	}
	
	public void setBlNO(String blNO) {
		this.blNO = blNO;
	}
	
	public String getMarksNumbers() {
		return MarksNumbers;
	}
	
	public void setMarksNumbers(String marksNumbers) {
		MarksNumbers = marksNumbers;
	}
	
	public String getDescription() {
		return Description;
	}
	
	public void setDescription(String description) {
		Description = description;
	}
	
	
	

}
