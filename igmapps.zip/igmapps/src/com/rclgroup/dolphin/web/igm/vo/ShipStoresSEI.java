package com.rclgroup.dolphin.web.igm.vo;
public class ShipStoresSEI{
     
        public String seqNmbr;
        public String articleNameCdd;
        public String articleNameText;
        public String locOnbrdText;
        public String qntyOnbrd;
        public String qntyCdOnbrd;
		public String getSeqNmbr() {
			return seqNmbr;
		}
		public void setSeqNmbr(String seqNmbr) {
			this.seqNmbr = seqNmbr;
		}
		public String getArticleNameCdd() {
			return articleNameCdd;
		}
		public void setArticleNameCdd(String articleNameCdd) {
			this.articleNameCdd = articleNameCdd;
		}
		public String getArticleNameText() {
			return articleNameText;
		}
		public void setArticleNameText(String articleNameText) {
			this.articleNameText = articleNameText;
		}
		public String getLocOnbrdText() {
			return locOnbrdText;
		}
		public void setLocOnbrdText(String locOnbrdText) {
			this.locOnbrdText = locOnbrdText;
		}
		public String getQntyOnbrd() {
			return qntyOnbrd;
		}
		public void setQntyOnbrd(String qntyOnbrd) {
			this.qntyOnbrd = qntyOnbrd;
		}
		public String getQntyCdOnbrd() {
			return qntyCdOnbrd;
		}
		public void setQntyCdOnbrd(String qntyCdOnbrd) {
			this.qntyCdOnbrd = qntyCdOnbrd;
		}
      }
    