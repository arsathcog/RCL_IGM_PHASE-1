package com.rclgroup.dolphin.web.igm.vo;

public class TmAdtnlDec {
          
              public String tagRef;
              public String refSerialNo;
              public String infoTyp;
              public String infoQualifier;
              public String  infoCd;
              public String  infoText   ;       
              public String  infoMsr;
              public String  infoDt;
 }