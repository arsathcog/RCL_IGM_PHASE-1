package com.rclgroup.dolphin.web.igm.vo;

public  class TmSuprtDocs{
             public String tagRef;
              public String refSerialNo;
              public String subSerialNoRef;
              public String icegateUserid;
              public String irnNmbr;
              public String docRefNmbr;
              public String docTypCd;
              public String bnefcryCdpublic ; 
}