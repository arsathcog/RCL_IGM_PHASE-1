package com.rclgroup.dolphin.web.igm.vo;

public class VesselDtlsSEI {
	
		public String modeOfTrnsprt;
		public String typOfTrnsprtMeans;
		public String trnsprtMeansId;
		
		public String getModeOfTrnsprt() {
			return modeOfTrnsprt;
		}
		public void setModeOfTrnsprt(String modeOfTrnsprt) {
			this.modeOfTrnsprt = modeOfTrnsprt;
		}
		public String getTypOfTrnsprtMeans() {
			return typOfTrnsprtMeans;
		}
		public void setTypOfTrnsprtMeans(String typOfTrnsprtMeans) {
			this.typOfTrnsprtMeans = typOfTrnsprtMeans;
		}
		public String getTrnsprtMeansId() {
			return trnsprtMeansId;
		}
		public void setTrnsprtMeansId(String trnsprtMeansId) {
			this.trnsprtMeansId = trnsprtMeansId;
		}

}
