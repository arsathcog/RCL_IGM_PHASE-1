package com.rclgroup.dolphin.web.igm.vo;

  //# 
public  class VisaDtls{
                public String prsnVisa  = ""; //  70
                public String pnrNmbr   = ""; //   20
    }